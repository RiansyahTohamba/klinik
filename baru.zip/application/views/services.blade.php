
<!-- Home -->

<div class="home d-flex flex-column align-items-start justify-content-end">
	<div class="parallax_background parallax-window" data-parallax="scroll" data-image-src="images/#" data-speed="0.8"></div>
	<div class="home_overlay"><img src="images/home_overlay.png" alt=""></div>
	<div class="home_container">
		<div class="container">
			<div class="row">
				<div class="col">
					<div class="home_content">
						<div class="home_title">Services</div>
						<div class="home_text">Lorem ipsum dolor sit amet, consectetur adipiscing elit.</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<!-- Services -->

<div class="services">
	<div class="container">
		<div class="row">
			<div class="col text-center">
				<div class="section_title_container">
					<div class="section_subtitle">This is Dr Pro</div>
					<div class="section_title"><h2>Our Services</h2></div>
				</div>
			</div>
		</div>
		<div class="row services_row">
			
			<!-- Service -->
			<div class="col-xl-4 col-md-6 service_col">
				<div class="service text-center">
					<div class="service">
						<div class="icon_container d-flex flex-column align-items-center justify-content-center ml-auto mr-auto">
							<div class="icon"><img src="images/icon_4.svg" alt="https://www.flaticon.com/authors/prosymbols"></div>
						</div>
						<div class="service_title">Breast Augmentation</div>
						<div class="service_text">
							<p>Odio ultrices ut. Etiam ac erat ut enim maximus accumsan vel ac nisl. Duis feugiat bibendum orci, non elementum urna.</p>
						</div>
					</div>
				</div>
			</div>

			<!-- Service -->
			<div class="col-xl-4 col-md-6 service_col">
				<div class="service text-center">
					<div class="service">
						<div class="icon_container d-flex flex-column align-items-center justify-content-center ml-auto mr-auto">
							<div class="icon"><img src="images/icon_5.svg" alt="https://www.flaticon.com/authors/prosymbols"></div>
						</div>
						<div class="service_title">Breast Augmentation</div>
						<div class="service_text">
							<p>Odio ultrices ut. Etiam ac erat ut enim maximus accumsan vel ac nisl. Duis feugiat bibendum orci, non elementum urna.</p>
						</div>
					</div>
				</div>
			</div>

			<!-- Service -->
			<div class="col-xl-4 col-md-6 service_col">
				<div class="service text-center">
					<div class="service">
						<div class="icon_container d-flex flex-column align-items-center justify-content-center ml-auto mr-auto">
							<div class="icon"><img src="images/icon_6.svg" alt="https://www.flaticon.com/authors/prosymbols"></div>
						</div>
						<div class="service_title">Breast Augmentation</div>
						<div class="service_text">
							<p>Odio ultrices ut. Etiam ac erat ut enim maximus accumsan vel ac nisl. Duis feugiat bibendum orci, non elementum urna.</p>
						</div>
					</div>
				</div>
			</div>

			<!-- Service -->
			<div class="col-xl-4 col-md-6 service_col">
				<div class="service text-center">
					<div class="service">
						<div class="icon_container d-flex flex-column align-items-center justify-content-center ml-auto mr-auto">
							<div class="icon"><img src="images/icon_7.svg" alt="https://www.flaticon.com/authors/prosymbols"></div>
						</div>
						<div class="service_title">Breast Augmentation</div>
						<div class="service_text">
							<p>Odio ultrices ut. Etiam ac erat ut enim maximus accumsan vel ac nisl. Duis feugiat bibendum orci, non elementum urna.</p>
						</div>
					</div>
				</div>
			</div>

			<!-- Service -->
			<div class="col-xl-4 col-md-6 service_col">
				<div class="service text-center">
					<div class="service">
						<div class="icon_container d-flex flex-column align-items-center justify-content-center ml-auto mr-auto">
							<div class="icon"><img src="images/icon_8.svg" alt="https://www.flaticon.com/authors/prosymbols"></div>
						</div>
						<div class="service_title">Breast Augmentation</div>
						<div class="service_text">
							<p>Odio ultrices ut. Etiam ac erat ut enim maximus accumsan vel ac nisl. Duis feugiat bibendum orci, non elementum urna.</p>
						</div>
					</div>
				</div>
			</div>

			<!-- Service -->
			<div class="col-xl-4 col-md-6 service_col">
				<div class="service text-center">
					<div class="service">
						<div class="icon_container d-flex flex-column align-items-center justify-content-center ml-auto mr-auto">
							<div class="icon"><img src="images/icon_3.svg" alt="https://www.flaticon.com/authors/prosymbols"></div>
						</div>
						<div class="service_title">Breast Augmentation</div>
						<div class="service_text">
							<p>Odio ultrices ut. Etiam ac erat ut enim maximus accumsan vel ac nisl. Duis feugiat bibendum orci, non elementum urna.</p>
						</div>
					</div>
				</div>
			</div>

		</div>
	</div>
</div>

<!-- Before and After -->

<div class="before_and_after">
	<div class="container">
		<div class="row">
			<div class="col">
				<div class="section_title_container text-center">
					<div class="section_subtitle">This is Dr Pro</div>
					<div class="section_title"><h2>Before & After Gallery</h2></div>
				</div>
			</div>
		</div>
		<div class="row before_and_after_row">
			<div class="col">
				<div class="ba_container">
					<figure class="cd-image-container">
						<img src="images/before.jpg" alt="Original Image">
						<span class="cd-image-label" data-type="original"></span>

						<div class="cd-resize-img">
							<img src="images/after.jpg" alt="Modified Image">
							<span class="cd-image-label" data-type="modified"></span>
						</div>

						<span class="cd-handle"></span>
					</figure>
				</div>
				<div class="ba_text text-center"><p>Nulla facilisi. Nulla egestas vel lacus sed interdum. Sed mollis, orci elementum eleifend tempor, nunc libero porttitor tellus.</p></div>
				<div class="ba_button_container text-center">
					<div class="button button_1 ba_button"><a href="#">see gallery</a></div>
				</div>
				
			</div>
		</div>
	</div>
</div>

<!-- Prices -->

<div class="prices">
	<div class="container">
		<div class="row">
			
			<!-- Price -->
			<div class="col-lg-6 price_col">
				<div class="price">
					<div class="price_title">Breast Augmentation</div>
					<div class="price_text">
						<p>Integer aliquet congue libero, eu gravida odio ultrces ut. Etiam ac erat ut enim maximus accumsan vel ac nisl.</p>
					</div>
					<div class="price_panel">From $3500</div>
				</div>
			</div>

			<!-- Price -->
			<div class="col-lg-6 price_col">
				<div class="price">
					<div class="price_title">Otoplasty</div>
					<div class="price_text">
						<p>Integer aliquet congue libero, eu gravida odio ultrces ut. Etiam ac erat ut enim maximus accumsan vel ac nisl.</p>
					</div>
					<div class="price_panel">From $2000</div>
				</div>
			</div>

			<!-- Price -->
			<div class="col-lg-6 price_col">
				<div class="price">
					<div class="price_title">Eyelid Surgery</div>
					<div class="price_text">
						<p>Integer aliquet congue libero, eu gravida odio ultrces ut. Etiam ac erat ut enim maximus accumsan vel ac nisl.</p>
					</div>
					<div class="price_panel">From $1500</div>
				</div>
			</div>

			<!-- Price -->
			<div class="col-lg-6 price_col">
				<div class="price">
					<div class="price_title">Botox</div>
					<div class="price_text">
						<p>Integer aliquet congue libero, eu gravida odio ultrces ut. Etiam ac erat ut enim maximus accumsan vel ac nisl.</p>
					</div>
					<div class="price_panel">From $200</div>
				</div>
			</div>

			<!-- Price -->
			<div class="col-lg-6 price_col">
				<div class="price">
					<div class="price_title">Liposuction</div>
					<div class="price_text">
						<p>Integer aliquet congue libero, eu gravida odio ultrces ut. Etiam ac erat ut enim maximus accumsan vel ac nisl.</p>
					</div>
					<div class="price_panel">From $5500</div>
				</div>
			</div>

			<!-- Price -->
			<div class="col-lg-6 price_col">
				<div class="price">
					<div class="price_title">Hyaluronic Acid</div>
					<div class="price_text">
						<p>Integer aliquet congue libero, eu gravida odio ultrces ut. Etiam ac erat ut enim maximus accumsan vel ac nisl.</p>
					</div>
					<div class="price_panel">From $350</div>
				</div>
			</div>

		</div>
	</div>
</div>

<!-- Newsletter -->

<div class="newsletter">
	<div class="parallax_background parallax-window" data-parallax="scroll" data-image-src="images/newsletter.jpg" data-speed="0.8"></div>
	<div class="container">
		<div class="row">
			<div class="col text-center">
				<div class="newsletter_title">Subscribe to our newsletter</div>
			</div>
		</div>
		<div class="row newsletter_row">
			<div class="col-lg-8 offset-lg-2">
				<div class="newsletter_form_container">
					<form action="#" id="newsleter_form" class="newsletter_form">
						<input type="email" class="newsletter_input" placeholder="Your E-mail" required="required">
						<button class="newsletter_button">subscribe</button>
					</form>
				</div>
			</div>
		</div>
	</div>
</div>
